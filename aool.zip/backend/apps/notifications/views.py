from django.shortcuts import render

def notification_list(request):
    """Отображение списка всех оповещений"""
    return render(request, 'notifications/list.html')

